#! /bin/bash

javac Banco/*.java
java Banco/Main
