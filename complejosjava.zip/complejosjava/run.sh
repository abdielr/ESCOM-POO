#! /bin/bash

javac Complejos/*.java
java Complejos/Main
