package photoalbum;
public class Main{
    public static void main(String[] args){
	try{
	    Album album = new Album();	
	}catch(Exception e ){
	    System.out.println();
	}

    }

}
