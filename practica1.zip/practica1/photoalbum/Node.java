package photoalbum;
public class Node{
    String data;
    Node next;
    Node prev;
}
