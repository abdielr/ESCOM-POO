#! /bin/bash
javac photoalbum/*.java
java photoalbum/Main
