#!/bin/bash

javac Fracciones/*.java

java Fracciones/mainFracciones
