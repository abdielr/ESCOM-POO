#! /bin/sh
gcc main.c rational.h rational.c -o out -lm
./out

